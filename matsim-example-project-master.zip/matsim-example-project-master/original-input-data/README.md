Suggestion to put original input data into this directory.  

Suggestion to put input data for MATSim runs into the `scenario` directory.

Suggestion to put results as subdirectories into the corresponding `scenario` directory.
